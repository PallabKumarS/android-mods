#!/system/bin/sh
# HyperOS AON AOD v3.1
# Targets the device-codename feature XML instead of guessing from XML contents.

MODDIR="${0%/*}"
FEATURE_DIR="/product/etc/device_features"
WORK_DIR="$MODDIR/work"

log() {
    echo "[HyperOS-AON-AOD] $1"
}

DEVICE="$(getprop ro.product.device)"

if [ -z "$DEVICE" ]; then
    log "Could not determine ro.product.device; nothing changed."
    exit 0
fi

TARGET="$FEATURE_DIR/$DEVICE.xml"

log "Device: $DEVICE"
log "Target: $TARGET"

if [ ! -f "$TARGET" ]; then
    log "Device feature XML not found; nothing changed."
    exit 0
fi

# Only operate on the intended feature file.
if ! grep -q '<bool name="is_only_support_keycode_goto">' "$TARGET" 2>/dev/null; then
    log "Target feature is not present; nothing changed."
    exit 0
fi

mkdir -p "$WORK_DIR"
NAME="${TARGET##*/}"
SRC="$WORK_DIR/$NAME"

if ! cp -af "$TARGET" "$SRC"; then
    log "Failed to create writable feature copy."
    exit 1
fi

# Change only true -> false. Do not add the feature if it is absent.
if ! sed -i \
    's#<bool name="is_only_support_keycode_goto">true</bool>#<bool name="is_only_support_keycode_goto">false</bool>#' \
    "$SRC"; then
    log "Failed to modify feature XML."
    exit 1
fi

# Preserve the original file's SELinux context.
if command -v chcon >/dev/null 2>&1; then
    chcon --reference="$TARGET" "$SRC" 2>/dev/null || true
fi

if ! mount -o bind "$SRC" "$TARGET"; then
    log "Bind mount failed."
    exit 1
fi

log "Successfully bind-mounted modified $NAME"

VALUE="$(grep -o '<bool name="is_only_support_keycode_goto">[^<]*</bool>' "$TARGET" 2>/dev/null)"
log "Active value: $VALUE"

exit 0
