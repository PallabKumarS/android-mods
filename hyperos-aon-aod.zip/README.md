# HyperOS AON AOD

Systemless HyperOS feature-gate override.

The module reads `ro.product.device` and targets:

`/product/etc/device_features/<device>.xml`

It changes only:

`is_only_support_keycode_goto=true`

to:

`is_only_support_keycode_goto=false`

The module contains no device-specific XML and does not move its payload into Meta OverlayFS because `skip_mount` is present.

If the device XML or target feature is not found, the module makes no changes.

Tested target: Xiaomi Garnet.
