#!/system/bin/sh
MODDIR=${0%/*}

# Early post-fs-data initialization if needed
