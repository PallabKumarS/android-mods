SKIPUNZIP=0

ui_print "*****************************************"
ui_print "*      AOD Dimmer for MIUI / HyperOS    *"
ui_print "*        KernelSU / Magisk / APatch     *"
ui_print "*****************************************"

ui_print "- Checking device configuration..."
DEVICE_MODEL=$(getprop ro.product.model)
DEVICE_BRAND=$(getprop ro.product.brand)
ui_print "- Device: $DEVICE_BRAND $DEVICE_MODEL"

ui_print "- Configuring permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644
if [ -f "$MODPATH/service.sh" ]; then
    set_perm "$MODPATH/service.sh" 0 0 0755
fi
if [ -f "$MODPATH/post-fs-data.sh" ]; then
    set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
fi

ui_print "- Installation successful!"
ui_print "- Please reboot your device to apply changes."
